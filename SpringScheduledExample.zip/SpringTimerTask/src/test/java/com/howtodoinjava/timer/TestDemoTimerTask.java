package com.howtodoinjava.timer;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestDemoTimerTask {
	public static void main(String[] args) {
		new ClassPathXmlApplicationContext("application-config.xml");
	}
}
