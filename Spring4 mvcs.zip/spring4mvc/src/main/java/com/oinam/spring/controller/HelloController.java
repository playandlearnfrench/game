package com.oinam.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@GetMapping("/hello")
	public String hello(Model model) {

		model.addAttribute("name", "Oinam Singh");

		return "welcome";
	}
	
	@RequestMapping("/welcome")
	public ModelAndView helloWorld() {
 
		String name = "This message is coming from helloWorld";
		return new ModelAndView("welcome", "name", name);
	}
}
