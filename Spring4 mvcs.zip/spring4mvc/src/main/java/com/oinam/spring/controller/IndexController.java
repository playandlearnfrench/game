package com.oinam.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
//@RequestMapping("/")
@RequestMapping("/indexCon")
public class IndexController {

	  @RequestMapping(method = RequestMethod.GET)
	  public String getIndexPage(Model model) {
		  model.addAttribute("name", "Oinam Singh");
	      return "welcome";
	  }

}